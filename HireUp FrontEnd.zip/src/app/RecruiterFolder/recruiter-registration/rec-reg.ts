export class RecReg{

    companyName!:string;
    recruiterName! : string;
    contactEmail! : string;
    currentBranch!: string;
    describeCompany! : string;
    companyWebsite! : string;
    userName!: string;
    password! : string;

    
}

