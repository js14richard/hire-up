import { RecReg } from './rec-reg';

describe('RecReg', () => {
  it('should create an instance', () => {
    expect(new RecReg()).toBeTruthy();
  });
});
