export class PostJob {
    jobRole!:String
	noOfVacancies!:String
	companyName!:String
	higherEducationQualification!:String
	workExperience!:String
	skills!:String
	location!:String
	gender!:String
	natureOfJob!:String
	wfhAllowed!:String
	salaryRange!:String
	department!:String
	workTiming!:String
	jobDescription!:String
}
