import { PostJob } from './post-job';

describe('PostJob', () => {
  it('should create an instance', () => {
    expect(new PostJob()).toBeTruthy();
  });
});
