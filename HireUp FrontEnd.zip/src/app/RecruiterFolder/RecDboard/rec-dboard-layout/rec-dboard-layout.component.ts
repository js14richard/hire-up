import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rec-dboard-layout',
  templateUrl: './rec-dboard-layout.component.html',
  styleUrls: ['./rec-dboard-layout.component.css']
})
export class RecDboardLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
