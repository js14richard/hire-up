import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rec-sidebar',
  templateUrl: './rec-sidebar.component.html',
  styleUrls: ['./rec-sidebar.component.css']
})
export class RecSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
