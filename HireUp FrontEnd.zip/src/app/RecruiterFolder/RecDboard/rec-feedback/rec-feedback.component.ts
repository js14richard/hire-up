import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rec-feedback',
  templateUrl: './rec-feedback.component.html',
  styleUrls: ['./rec-feedback.component.css']
})
export class RecFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
