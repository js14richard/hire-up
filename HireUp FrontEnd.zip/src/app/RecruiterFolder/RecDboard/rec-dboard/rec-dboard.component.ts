import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rec-dboard',
  templateUrl: './rec-dboard.component.html',
  styleUrls: ['./rec-dboard.component.css']
})
export class RecDboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
