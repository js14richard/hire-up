import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rec-view-resume',
  templateUrl: './rec-view-resume.component.html',
  styleUrls: ['./rec-view-resume.component.css']
})
export class RecViewResumeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
