import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-section',
  templateUrl: './register-section.component.html',
  styleUrls: ['./register-section.component.css']
})
export class RegisterSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
