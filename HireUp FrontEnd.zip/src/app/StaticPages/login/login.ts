export class Login {
    userName!:String;
    password!:String;

}
