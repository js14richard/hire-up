export class CandReg {
    
    firstName!:string;
    lastName!:string;
    fatherName!:string;
    email !:string;
    gender!:string;
    skills!:string;
    location !:string;
    willingToWork!:string;
    higherEducation!:string;
    workExperience!:string;
    dateOfBirth!:string;
    describeYourself!:string;
    userName !:string;
    password!:string;
}
