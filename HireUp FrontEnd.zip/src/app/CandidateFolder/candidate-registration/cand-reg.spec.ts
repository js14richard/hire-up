import { CandReg } from './cand-reg';

describe('CandReg', () => {
  it('should create an instance', () => {
    expect(new CandReg()).toBeTruthy();
  });
});
