import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dboard-layout',
  templateUrl: './dboard-layout.component.html',
  styleUrls: ['./dboard-layout.component.css']
})
export class DBoardLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
