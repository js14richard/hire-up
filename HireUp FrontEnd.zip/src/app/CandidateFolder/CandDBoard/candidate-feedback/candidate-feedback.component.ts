import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-feedback',
  templateUrl: './candidate-feedback.component.html',
  styleUrls: ['./candidate-feedback.component.css']
})
export class CandidateFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
