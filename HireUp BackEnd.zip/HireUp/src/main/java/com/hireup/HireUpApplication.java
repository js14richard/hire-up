package com.hireup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HireUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(HireUpApplication.class, args);	
	}
}

